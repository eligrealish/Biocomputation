class individual:
    def __init__(self, chromosome=[], fitness=0):
        # print("-------INDIVIDUAL CREATED-------")
        self.chromosome = chromosome
        self.fitness = fitness